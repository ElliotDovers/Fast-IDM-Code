#' Gorilla Nesting Sites
#'
#' This is the `gorillas` dataset from the package `spatstat` (also featured in `inlabru`), formatted for use with `scampr` models. Describes the nesting locations of gorillas, and associated predictors, in Kagwene Gorilla Sanctuary in Cameroon.
#'
#' @format A data frame with 26020 rows and 11 variables:
#' \describe{
#'   \item{x}{Horizontal coordinate in units Easting.}
#'   \item{y}{Vertical coordinate in units Northing.}
#'   \item{quad.size}{Size of the quadrat in Northing/Easting units squared.}
#'   \item{aspect}{Compass direction of the terrain slope. Categorical, with levels N, NE, E, SE, S, SW, W and NW, which are coded as integers 1 to 8.}
#'   \item{elevation}{Digital elevation of terrain, in metres.}
#'   \item{heat}{Heat Load Index at each point on the surface (Beer's aspect), discretised. Categorical with values Warmest (Beer's aspect between 0 and 0.999), Moderate (Beer's aspect between 1 and 1.999), Coolest (Beer's aspect equals 2). These are coded as integers 1, 2 and 3, in that order.}
#'   \item{slopeangle}{Terrain slope, in degrees.}
#'   \item{slopetype}{Type of slope. Categorical, with values Valley, Toe (toe slope), Flat, Midslope, Upper and Ridge. These are coded as integers 1 to 6.}
#'   \item{vegetation}{Vegetation type: a categorical variable with 6 levels coded as integers 1 to 6 (in order of increasing expected habitat suitability).}
#'   \item{waterdist}{Euclidean distance from nearest water body, in metres.}
#'   \item{pres}{Binary indicating whether the row is a presence record (1) or a quadrat (0).}
#' }
#' @source \url{Library `inlabru`}
"gorillas"
