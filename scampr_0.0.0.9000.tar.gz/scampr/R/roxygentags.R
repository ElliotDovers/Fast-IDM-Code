#' Roxygen commands
#'
#' @useDynLib scampr
#'
ROxygenTags <- function(){
  return(NULL)
}
