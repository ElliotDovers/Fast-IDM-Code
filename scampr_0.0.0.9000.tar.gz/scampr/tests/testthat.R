library(testthat)
library(scampr)

test_check("scampr")
